Run:
pip install -r requirements.txt
python backend/youtube_api.py
python backend/model_train.py
python backend/app.py
