async function loadData() {
 const channels = await (await fetch('/api/channels')).json();
 const names = channels.map(d => d.channel_name);
 const subs = channels.map(d => d.subscribers);

 Plotly.newPlot('chart1', [{x:names,y:subs,type:'bar'}]);
}
loadData();
