import os
import csv
from googleapiclient.discovery import build
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("YOUTUBE_API_KEY")

CHANNEL_IDS = {
    "T-Series": "UCq-Fj5jknLsUf-MWSy4_brA",
    "MrBeast": "UCX6OQ3DkcsbYNE6H8uQQuVA",
    "Cocomelon": "UCbCmjCuTUZos6Inko4u57UQ",
    "SET India": "UCpEhnqL0y41EpW2TvWAHD7Q",
    "ETV Dhee": "UCs9jCBoQmi4HBk8JjP3iD5A",
    "Zee Music Company": "UCFFbwnve3yF62-tVXkTyHqg",
    "5-Minute Crafts": "UC295-Dw_tDNtZXFeAPAW6Aw",
    "Village Cooking Channel": "UCk3JZr7eS3pg5AGEvBdEvBg",
    "Dobre Brothers": "UCj4u9I6u1qVxG3X2X8y2Y2g"
}

def fetch_channels():
    youtube = build("youtube", "v3", developerKey=API_KEY)
    rows = []

    response = youtube.channels().list(
        part="snippet,statistics",
        id=",".join(CHANNEL_IDS.values())
    ).execute()

    for item in response.get("items", []):
        stats = item["statistics"]
        videos = int(stats.get("videoCount", 0))
        views = int(stats.get("viewCount", 0))
        subs = int(stats.get("subscriberCount", 0))

        rows.append({
            "channel_name": item["snippet"]["title"],
            "subscribers": subs,
            "videos": videos,
            "total_views": views,
            "country": item["snippet"].get("country", "Unknown"),
            "category": "Unknown",
            "avg_views_per_video": round(views / videos, 2) if videos else 0,
            "subscriber_to_views_ratio": round(subs / views, 6) if views else 0
        })

    return rows

def save_csv(rows):
    os.makedirs("data", exist_ok=True)
    with open("data/channels.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

if __name__ == "__main__":
    data = fetch_channels()
    save_csv(data)
