from flask import Flask, jsonify, send_from_directory
import pandas as pd

app = Flask(__name__, static_folder="../frontend", static_url_path="")
df = pd.read_csv("data/channels.csv")

@app.route("/api/channels")
def channels():
    return jsonify(df.to_dict(orient="records"))

@app.route("/api/summary")
def summary():
    return jsonify({
        "total_channels": int(df.shape[0]),
        "total_subscribers": int(df["subscribers"].sum()),
        "total_videos": int(df["videos"].sum()),
        "total_views": int(df["total_views"].sum())
    })

@app.route("/")
def home():
    return send_from_directory(app.static_folder, "index.html")

if __name__ == "__main__":
    app.run(debug=True)
