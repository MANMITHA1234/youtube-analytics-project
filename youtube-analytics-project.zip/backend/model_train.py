import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
import joblib
import os

df = pd.read_csv("data/channels.csv").fillna(0)

X = df[["videos", "total_views", "avg_views_per_video", "subscriber_to_views_ratio"]]
y = df["subscribers"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

model = RandomForestRegressor(n_estimators=200)
model.fit(X_train, y_train)

pred = model.predict(X_test)
print("MAE:", mean_absolute_error(y_test, pred))

os.makedirs("models", exist_ok=True)
joblib.dump(model, "models/channel_model.pkl")
